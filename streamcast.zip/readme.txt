=== StreamCast – Live Radio Streaming Player ===
Contributors: bplugins, taninrahman, shehabulislam, freemius
Tags: live stream, icecast, shoutcast, radio player, audio player
Donate link: https://www.buymeacoffee.com/abuhayat
Requires at least: 6.2
Tested up to: 7.0
Stable tag: 2.4.3
Requires PHP: 7.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

StreamCast allows you to play IceCast, Shoutcast, Radionomy, RadioJar, RadioCo and more beautifully inside WordPress.

== Description ==

### The #1 No-Code Radio Player Plugin for WordPress – Trusted by Thousands Worldwide

StreamCast is a simple, accessible, and fully customizable online radio streaming player for WordPress.

Play **IceCast**, **Shoutcast**, **RadioCo**, **RadioJar**, **Radionomy**, and many more stream types using shortcodes or Gutenberg blocks — without writing code.

It’s lightweight, fast, responsive, and works across all major browsers and devices.

Whether you run an online radio station, podcast live stream, community FM, or educational broadcast—StreamCast lets you embed your live stream beautifully inside WordPress.

[**StreamCast**](https://bplugins.com/products/streamcast-radio-player/) | [**Documentation**](https://bplugins.com/docs/streamcast-radio-player/) | [**Pricing**](https://bplugins.com/products/streamcast-radio-player/pricing/) | [**Support**](https://bplugins.com/support/) | [**Demo**](https://bplugins.com/products/streamcast-radio-player/#demos)

= How To Use It? Learn Quick = 

https://www.youtube.com/watch?v=ad_LKLe_YQg

---

### Key Features (Free)

* **Responsive Radio Player** – Works on desktop, tablet, and mobile.  
* **Supports Major Providers** – IceCast, Shoutcast, Radiojar, Radionomy, RadioCo & more.  
* **No-Code Setup** – Add with a simple shortcode or Gutenberg block.  
* **Customizable Skins** – Adjust background colors and styles.  
* **Cross-Browser Compatible** – Chrome, Firefox, Safari, Edge.  
* **Lightweight & Fast** – Minimal load, no performance issues.  
* **Single Station Player** – Designed for one stream per page.  
* **Background Color Support** – Personalize using shortcode attributes.

---

### 🎧 StreamCast Pro – Premium Version Features

The **StreamCast Premium** version includes advanced player controls, professional skins, and full customization options.

**Pro Features Include:**

* Advanced Player UI (85+ Radio Player)
* Professional Skin Library  
* Automatic Station Name From Stream URL
* Brand Color Picker & Custom Colors  
* Text Color & Typography
* Ultimate Player Type  
* More Stream Compatibility  
* Custom CSS Styling  
* Priority Support & Future Updates  

👉 [**Get Premium Version**](https://bplugins.com/products/streamcast-radio-player/pricing/)

---

== How to Use ==

### Add a Simple Player
Use this shortcode: [stream url="YOUR_STREAM_URL"]

### Add a Background Color
[stream url="YOUR_STREAM_URL" background="#333333"]

Supports color names or hex values.


Or use the **Gutenberg StreamCast Block** for a visual setup.

---

== Important Notes ==

### ⚠️ Chrome 80+ Restriction  
If your website uses HTTPS but your stream is HTTP, Chrome will block playback.

✔ Both website and stream must use the same protocol (preferably HTTPS).

More info: https://blog.chromium.org/2019/10/no-more-mixed-messages-about-https.html

---

== Use Cases ==

* Online radio stations  
* Internet broadcast channels  
* Podcast live streams  
* Religious or community radio  
* Live music streams  
* FM/AM radio going digital  
* Educational radio broadcasts  

---


== User Feedback ==

⭐⭐⭐⭐⭐ **“This is exactly what I was looking for – I have a station on Live365 and their ‘player’ is too large, I wanted a simple player without all the mumbo jumbo. So far so good.”**

⭐⭐⭐⭐⭐ **“It’s best radio player, so many features. can put player anywhere by short code.
I recommended”**

Have suggestions? Let us know: https://bplugins.com/contact

---

== Installation ==

You can install the Streamcast plugin in three ways.

= From the WordPress Dashboard =
1. Log in to your WordPress admin dashboard.
2. Go to Plugins > Add New.
3. Search for "Streamcast" (developed by **bPlugins**).
4. Click Install Now.
5. After installation, click Activate.

= Download & Upload =
1. Download the Streamcast plugin (streamcast.zip).
2. Log in to your WordPress admin dashboard.
3. Go to Plugins > Add New.
4. Click Upload Plugin.
5. Select the streamcast.zip file and click Install Now.
6. Activate the plugin after installation.

= Manual Installation =
1. Download the Streamcast plugin.
2. Extract the zip file.
3. Upload the streamcast folder to the /wp-content/plugins/ directory using FTP or File Manager.
4. Log in to your WordPress admin dashboard.
5. Go to Plugins > Installed Plugins.
6. Activate Streamcast from the plugins list.



== Frequently Asked Questions ==

= How do I install this plugin? =
You can install it as other regular WordPress plugins. No different way. Please see on installation tab.

= What type of stream URLs are supported by StreamCast? =
StreamCast supports most major radio streaming formats including:

* IceCast streams  
* Shoutcast streams  
* RadioCo  
* RadioJar  
* Radionomy  
* MP3 live stream URLs  
* AAC / AAC+ streams  
* OGG streams  

If your stream plays in a browser media player, StreamCast will work with it.


= The player is not playing my live stream. What should I do? =  
Check the protocols.  
If your website is **HTTPS** and your stream is **HTTP**, the browser will block it.  
Use matching protocols (HTTPS → HTTPS).

= The second player is not showing like the first one. Why? =  
Multiple players on a single page are not supported.

= Does StreamCast show live track or song information? =

StreamCast Pro supports live metadata (Now Playing) for compatible streams.

= Can I use StreamCast with Live365 or Radio.co stations? =
Yes. StreamCast is fully compatible with Live365, Radio.co, and most modern radio hosting providers. Just paste the live stream URL into the shortcode or block.

= Can I change the station name manually? =

Yes. You can manually set a custom station name.

StreamCast Pro can also fetch the station name automatically from the stream metadata.

= Can I use StreamCast on multiple websites? =

The free version can be used on unlimited websites.

Pro licenses are based on the plan you purchase.

= Does StreamCast affect website performance? =

No. StreamCast is lightweight and loads only when the player is present on the page.

= What should I do if my stream stops working suddenly? =

First, test the stream URL in your browser directly.

If it does not play there, the issue is with your radio provider — not the plugin.


= Does StreamCast work on mobile devices? =

Yes. StreamCast is fully responsive and works on:

* Android  
* iOS  
* Tablets  
* Desktop browsers  

= Is StreamCast compatible with future WordPress updates? =

Yes. StreamCast is actively maintained and tested with the latest WordPress versions.

= Can I use StreamCast inside Elementor or other builders? =

Yes. You can use the shortcode inside:

* Elementor  
* WPBakery  
* Divi  
* Beaver Builder  

It works with all page builders that support shortcodes.



= Where do I report security bugs found in this plugin? =
Please report security bugs found in the source code of the StreamCast plugin through the [Patchstack Vulnerability Disclosure Program](https://patchstack.com/database/vdp/9e5fb205-6f66-453b-bdaa-c7c587b83810). The Patchstack team will assist you with verification, CVE assignment, and notify the developers of this plugin.

== Source Code ==

You can find the source code, report bugs, and contribute to the development of this plugin on our GitHub repository: 
[**StreamCast on GitHub**](https://github.com/bPlugins/streamcast-wp)

== External Services ==

This plugin connects to the following external services to provide enhanced functionality:

1. **Muses Radio Player API** (muses.org)
   - Used for: Fetching player skins and sending anonymous usage statistics
   - Data sent: Player configuration and anonymous listener data (legacy player reports)
   - Loaded on: Pages where the radio player block or shortcode is displayed
   - Terms: https://www.muses.org/terms-and-conditions | Privacy Policy: https://www.muses.org/privacy-policy

2. **Plyr Video Player Assets** (Local)
   - Used for: Localized SVG icons and blank video assets for the Plyr player
   - Data sent: None (Assets are bundled locally)
   - Loaded on: Pages using the shortcode or block
   - Terms: https://plyr.io/ | Privacy Policy: https://plyr.io/

3. **YouTube Data API** (googleapis.com)
   - Used for: Fetching video/stream metadata (title) by video ID
   - Data sent: YouTube video ID and API key
   - Loaded on: Pages where a YouTube stream source is configured
   - Terms: https://policies.google.com/terms | Privacy: https://policies.google.com/privacy

4. **Google IMA SDK** (imasdk.googleapis.com)
   - Used for: Loading video ad support (VAST/VMAP ads)
   - Data sent: Standard ad request data
   - Loaded on: Pages
   - Terms: https://policies.google.com/terms | Privacy: https://policies.google.com/privacy

5. **Vimeo API** (vimeo.com)
   - Used for: Fetching Vimeo video metadata
   - Data sent: Vimeo video ID
   - Loaded on: Pages where a Vimeo stream source is configured
   - Terms: https://vimeo.com/terms | Privacy: https://vimeo.com/privacy

6. **AniView Ad Server** (go.aniview.com)
   - Used for: Serving VAST video ads
   - Data sent: Standard VAST ad request parameters
   - Loaded on: Pages where AniView ads are enabled
   - Terms: https://www.aniview.com/terms-of-service/ | Privacy Policy: https://www.aniview.com/privacy-policy/

7. **bPlugins Templates** (templates.bplugins.com)
   - Used for: Loading default radio station artwork and player skins
   - Data sent: Asset request (no personal data)
   - Loaded on: Admin dashboard and player initialization
   - Terms: https://bplugins.com/terms-of-service/ | Privacy Policy: https://bplugins.com/privacy-policy/

---

== Third-Party Libraries ==

This plugin bundles the following third-party JavaScript/PHP libraries.

= Codestar Framework =

* **Source:** [http://codestarframework.com/](http://codestarframework.com/)
* **GitHub:** [https://github.com/Codestar/codestar-framework](https://github.com/Codestar/codestar-framework)
* **License:** GPLv2 or later – [https://github.com/Codestar/codestar-framework/blob/master/LICENSE.md](https://github.com/Codestar/codestar-framework/blob/master/LICENSE.md)
* **Purpose:** Provides the options framework for the plugin's settings and shortcode generator.

= Freemius SDK =

* **Source:** [https://freemius.com/](https://freemius.com/)
* **GitHub:** [https://github.com/Freemius/wordpress-sdk](https://github.com/Freemius/wordpress-sdk)
* **License:** GPLv3 – [https://github.com/Freemius/wordpress-sdk/blob/master/LICENSE.txt](https://github.com/Freemius/wordpress-sdk/blob/master/LICENSE.txt)
* **Purpose:** Provides opt-in usage tracking and analytics to help improve the plugin.

= bpl-tools =
* Source / GitHub: https://github.com/bPlugins/bpl-tools
* License: GPL-2.0-or-later – https://www.gnu.org/licenses/gpl-2.0.html
* Purpose: Shared utility library providing admin dashboard components and common Gutenberg editor controls.
* External Services: The library may connect to bPlugins, WordPress.org, and Freemius services for product data and checkout functionality. See full details: https://github.com/bPlugins/bpl-tools#external-requests--why-they-are-made

== Screenshots ==

1. Admin Menu (ShortCodes)
2. Gutenberg Block
3. Wooden and AuroraPlay Radio Type
4. 3 Different Customizable Radio Type
5. EchoStream Radio Type
6. Standard Radio Type(80+ Radio Skins) 
7. Gutenberg Block Support

---

== Changelog ==

= 2.4.3 - 4 July 2026 =
* **Refactor:** Reorganized plugin architecture by keeping blocks under src/blocks/streamcast/ and admin dashboard under src/admin-dashboard/.
* **Refactor:** Realigned all backend PHP file and folder structures, namespaces, classes, and constants to match the StreamCast free repository on GitHub while preserving all premium-only features.
* **Update:** Upgraded admin dashboard welcome layout to use the unified bpl-tools Admin experience.

= 2.4.2 - 26 May 2026 =
* Update: Improved internal dependency loading structure using Composer autoloading.
* Fix: Strengthened validation and access controls in the option settings framework.
* Internationalization: Corrected translation text domain mapping for all checkbox fields.

= 2.4.1 - 10 May 2026 =
* Compliance: Renamed all global prefixes and namespaces from `STP` to `StreamCast` and `csf` to `streamcast_csf`.
* Security: Implemented robust output escaping and input sanitization across the entire codebase and framework.
* Security: Replaced all `json_encode` calls with `wp_json_encode` for safer data handling.
* Security: Sanitized all nonces and JSON-decoded data to prevent XSS and other vulnerabilities.
* Maintenance: Renamed generic JavaScript variables and structural cleanup to meet WordPress.org standards.

= 2.4.0 - 6 May 2026 =
* Compliance: Removed all trialware/feature-gating logic to ensure full functionality for all users.
* Compliance: Localized third-party assets (WebFontLoader, FontAwesome, Plyr, Muses) to eliminate remote CDN dependencies.
* Privacy: Removed unconditional Google Analytics tracking from the player script.
* Compliance: Standardized internationalization (i18n) by migrating all text domains to 'streamcast'.
* Security: Enhanced output escaping and data sanitization in shortcodes and Gutenberg blocks.
* Enhancement: Added explicit "External Services" and "Source Code" documentation in readme.txt.
* Fix: Updated shortcode attributes to correctly honor user-provided stream URLs and background colors.
* Maintenance: Updated compatibility tags and improved code adherence to WordPress.org standards.

= 2.3.9 - 23 February 2026 =
* **Update:** Redesigned the dashboard with a modern and improved user interface, replacing the previous outdated layout.

= 2.3.7 - 22 November 2025 =
* Updated readme.txt and fixed issues

= 2.3.6 - 2 November 2025 =
* Updated Advanced Radio Player

= 2.3.5 - 23 September 2025 =
* Accessibility: Added screen reader support

= 2.3.4 - 17 September 2025 =
* Added Modern Dashboard

= 2.3.1 - 17 May 2025 =
* Added new radio skin

= 2.3.0 - 19 Feb 2025 =
* Added Gutenberg block and redesigned plugin

= 2.2.4 - 30 July 2024 =
* Fixed Cross Site Scripting issue

= 2.2.3 - 4 July 2024 =
* Updated WordPress SDK

= 2.2.2 - 1 Jan 2024 =
* Fixed unexpected number issue

= 2.2.0 - 26 Aug 2023 =
* Added new premium skin "B Circle"

= 2.1.11 - 26 Aug 2023 =
* Fixed uncaught error at line 335

= 2.1.9 - 1 May 2023 =
* Updated Freemius SDK

= 2.1.8 - 1 May 2023 =
* Fixed ops issue

= 2.1.6 - 1 May 2023 =
* Added support for normal stream on ultimate player

= 2.1.6 - 22 Oct 2022 =
* Minor fixes

= 2.1.4 =
* Updated Freemius SDK

= 2.0.0 =
* Added player themes  
* Added Ultimate Radio Player type  
* Added custom color options  
* Added modern skins  

= 1.0 =
* Initial Release

